# Assume number is prime until shown it is not.
for possiblePrime in range(2, 250):

    isPrime = True
    for num in range(2, possiblePrime):
        if possiblePrime % num == 0:
            isPrime = False
    if isPrime:
        print(possiblePrime)